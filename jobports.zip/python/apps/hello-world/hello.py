import flet as ft


def main(page: ft.Page):
    page.add(ft.Text("Hello, world!"))


ft.app(main)
