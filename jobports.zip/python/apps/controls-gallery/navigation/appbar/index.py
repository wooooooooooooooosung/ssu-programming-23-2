name = "AppBar"
description = """A material design app bar."""
image_file = "appbar.svg"