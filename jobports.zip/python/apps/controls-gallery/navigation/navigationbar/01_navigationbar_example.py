import flet as ft

name = "NavigationBar Example"

def example():
    
    return ft.Text("This example is under construction")