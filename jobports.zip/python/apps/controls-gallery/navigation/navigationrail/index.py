name = "NavigationRail"
description = """A material widget that is meant to be displayed at the left or right of an app to navigate between a small number of views, typically between three and five."""
image_file = "navigationrail.svg"