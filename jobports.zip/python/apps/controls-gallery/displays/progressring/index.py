name = "ProgressRing"
description = """A material design circular progress indicator, which spins to indicate that the application is busy.

A control that shows progress along a circle."""
image_file = "progressring.svg"