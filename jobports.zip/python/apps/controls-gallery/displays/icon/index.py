name = "Icon"
description = """Displays a Material icon."""
image_file = "icon.svg"