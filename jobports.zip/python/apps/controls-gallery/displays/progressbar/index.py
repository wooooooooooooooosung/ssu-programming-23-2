name = "ProgressBar"
description = """A material design linear progress indicator, also known as a progress bar.

A control that shows progress along a line."""
image_file = "progressbar.svg"