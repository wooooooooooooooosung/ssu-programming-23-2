name = "PopupMenuButton"
description = """An icon button which displays a menu when clicked."""
image_file = "popupmenubutton.svg"