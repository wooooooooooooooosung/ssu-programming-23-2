name = "TextButton"
description = """Text buttons are used for the lowest priority actions, especially when presenting multiple options. Text buttons can be placed on a variety of backgrounds. Until the button is interacted with, its container isn’t visible."""
image_file = "textbutton.svg"