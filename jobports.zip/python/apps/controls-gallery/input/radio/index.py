name = "Radio"
description = """Radio buttons let people select a single option from two or more choices."""
image_file = "text.svg"