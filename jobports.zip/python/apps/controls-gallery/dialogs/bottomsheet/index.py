name = "BottomSheet"
description = """Shows a modal Material Design bottom sheet.

A modal bottom sheet is an alternative to a menu or a dialog and prevents the user from interacting with the rest of the app."""
image_file = "icon.svg"