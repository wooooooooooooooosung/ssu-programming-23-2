name = "VerticalDivider"
description = """A thin vertical line, with padding on either side.

In the material design language, this represents a divider."""
image_file = "verticaldivider.svg"