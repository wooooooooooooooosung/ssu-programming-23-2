name = "Column"
image_file = "column.svg"
description = "A control that displays its children in a vertical array."