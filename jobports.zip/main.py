from flet import *
from Menu import *


def main(page: Page):
    page.title = "Jobports"

    logo = Image(
            src = f"/잡포츠.png",
            width = 160,
            height = 80,
            fit = ImageFit.CONTAIN,)
    
    page.add(logo, tab_menu())
    page.update()


app(target = main, view = AppView.WEB_BROWSER, assets_dir = "home_page")